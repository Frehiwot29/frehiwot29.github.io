"use strict";
/*eslint-disable*/
const Iter = require('./list');
function sortRB(L) {
    let nextRed = L.first();
    while (!L.isLast() && nextRed.element() === RED) {
        nextRed = L.after(nextRed);
        let p = nextRed;
        while (!L.isLast(p)) {
            if (p.element() === RED) {
                L.swapElements(p, nextRed)
                nextRed = L.after(nextRed)
                p = L.after(p);
            }
        }
    }
    return p;
}
let list = new Iter.List()
list.insertFirst("R")
list.insertFirst("B")
list.insertFirst("B")
list.insertFirst("R")
list.insertFirst("B")
list.insertFirst("R")
list.insertFirst("R")
sortRB(list)
console.log(list);