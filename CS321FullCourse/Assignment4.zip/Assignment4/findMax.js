"use strict";
/*eslint-disable*/
const Iter = require('./list.js');
function findMax(L) {
    return maxHelper(L, L.first());
}
function maxHelper(L, p) {
    if (L.isEmpty()) {
        return 0;
    } else if (L.isList(p)) {
        return p.element();
    } else {
        return Math.max(p.element(), maxHelper(L, L.after(p)));
    }
}
let myList = new Iter.List();
myList.insertFirst(9)
myList.insertFirst(6)
myList.insertFirst(8)
myList.insertFirst(3)
myList.insertFirst(2);
findMax(myList);
console.log(myList);